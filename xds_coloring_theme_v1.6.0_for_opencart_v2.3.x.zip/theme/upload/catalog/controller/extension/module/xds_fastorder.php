<?php
class ControllerExtensionModuleXdsfastorder extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('extension/module/xds_fastorder');

		$this->document->setTitle($this->language->get('heading_title'));
		
		$this->load->model('catalog/product');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
			$mail = new Mail();
			$mail->protocol = $this->config->get('config_mail_protocol');
			$mail->parameter = $this->config->get('config_mail_parameter');
			$mail->smtp_hostname = $this->config->get('config_mail_smtp_hostname');
			$mail->smtp_username = $this->config->get('config_mail_smtp_username');
			$mail->smtp_password = html_entity_decode($this->config->get('config_mail_smtp_password'), ENT_QUOTES, 'UTF-8');
			$mail->smtp_port = $this->config->get('config_mail_smtp_port');
			$mail->smtp_timeout = $this->config->get('config_mail_smtp_timeout');

			$product_info = $this->model_catalog_product->getProduct($this->request->post['product_id']);
			
			$mailtext = $this->language->get('text_name') . $this->request->post['name'] . "\r\n";
			$mailtext .= $this->language->get('text_phone') . $this->request->post['phone']. "\r\n";
			$mailtext .= $this->language->get('text_product_name') . $product_info['name'] . "\r\n";
			$mailtext .= $this->language->get('text_product_href') . $this->url->link('product/product', 'product_id=' . $product_info['product_id']) . "\r\n";
			$mailtext .= $this->language->get('text_enquiry') . $this->request->post['enquiry'];

			$mail->setTo($this->config->get('config_email'));
			$mail->setFrom($this->config->get('config_email'));
			$mail->setSender(html_entity_decode($this->request->post['name'], ENT_QUOTES, 'UTF-8'));
			$mail->setSubject(html_entity_decode(sprintf($this->language->get('email_subject'), $this->request->post['name']), ENT_QUOTES, 'UTF-8'));
			$mail->setText(html_entity_decode($mailtext, ENT_QUOTES, 'UTF-8'));
			$mail->send();

			$this->response->redirect($this->url->link('extension/module/xds_fastorder/success'));
		}
		
		if (($this->request->server['REQUEST_METHOD'] == 'POST')) {
			$product_info = $this->model_catalog_product->getProduct($this->request->post['product_id']);
		} else {
			$product_info = $this->model_catalog_product->getProduct($this->request->get['product_id']);
		}
		
		
		$data['product_name'] = $product_info['name'];
		
		$data['product_href'] = $this->url->link('product/product', 'product_id=' . $product_info['product_id']);
		
		$data['product_description'] = $product_info['description'];
		
		if ($this->customer->isLogged() || !$this->config->get('config_customer_price')) {
			$data['product_price'] = $this->currency->format($this->tax->calculate($product_info['price'], $product_info['tax_class_id'], $this->config->get('config_tax')), $this->session->data['currency']);
		} else {
			$data['product_price'] = false;
		}

		if ((float)$product_info['special']) {
			$data['product_special'] = $this->currency->format($this->tax->calculate($product_info['special'], $product_info['tax_class_id'], $this->config->get('config_tax')), $this->session->data['currency']);
		} else {
			$data['product_special'] = false;
		}

		$this->load->model('tool/image');
		
		if ($product_info['image']) {
			$data['product_image'] = $this->model_tool_image->resize($product_info['image'], 210, 210);
		} else {
			$data['product_image'] = '';
		}
		

		$data['heading_title'] =  $this->language->get('heading_title') . ' ' . $product_info['name'];

		$data['entry_name'] = $this->language->get('entry_name');
		$data['entry_phone'] = $this->language->get('entry_phone');
		$data['entry_enquiry'] = $this->language->get('entry_enquiry');


		if (isset($this->error['name'])) {
			$data['error_name'] = $this->error['name'];
		} else {
			$data['error_name'] = '';
		}

		if (isset($this->error['phone'])) {
			$data['error_phone'] = $this->error['phone'];
		} else {
			$data['error_phone'] = '';
		}

		$data['button_submit'] = $this->language->get('button_submit');

		$data['action'] = $this->url->link('extension/module/xds_fastorder', '', true);

		if (isset($this->request->post['product_id'])) {
			$data['product_id'] = (int)$this->request->post['product_id'];
		} elseif (isset($this->request->get['product_id'])) {
			$data['product_id'] = (int)$this->request->get['product_id'];
		} else {
			$data['product_id'] = 0;
		}

		if (isset($this->request->post['name'])) {
			$data['name'] = $this->request->post['name'];
		} else {
			$data['name'] = $this->customer->getFirstName();
		}

		if (isset($this->request->post['phone'])) {
			$data['phone'] = $this->request->post['phone'];
		} else {
			$data['phone'] = '';
		}

		if (isset($this->request->post['enquiry'])) {
			$data['enquiry'] = $this->request->post['enquiry'];
		} else {
			$data['enquiry'] = '';
		}

		//	Captcha
		//	if ($this->config->get($this->config->get('config_captcha') . '_status') && in_array('contact', (array)$this->config->get('config_captcha_page'))) {
		//		$data['captcha'] = $this->load->controller('captcha/' . $this->config->get('config_captcha'), $this->error);
		//	} else {
		//		$data['captcha'] = '';
		//	}


		
		$data['stest'] = false;
		
		$this->response->setOutput($this->load->view('extension/module/xds_fastorder', $data));
	}

	protected function validate() {
		if ((utf8_strlen($this->request->post['name']) < 3) || (utf8_strlen($this->request->post['name']) > 32)) {
			$this->error['name'] = $this->language->get('error_name');
		}

		if ((utf8_strlen($this->request->post['phone']) < 3) || (utf8_strlen($this->request->post['phone']) > 20)) {
			$this->error['phone'] = $this->language->get('error_phone');
		}


		// Captcha
		//	if ($this->config->get($this->config->get('config_captcha') . '_status') && in_array('contact', (array)$this->config->get('config_captcha_page'))) {
		//		$captcha = $this->load->controller('captcha/' . $this->config->get('config_captcha') . '/validate');
		//		if ($captcha) {
		//			$this->error['captcha'] = $captcha;
		//		}
		//	}

		$data['stest'] = false;
		
		return !$this->error;
	}

	public function success() {
		$this->load->language('extension/module/xds_fastorder');

		$data['heading_title'] = $this->language->get('heading_title');

		$data['text_message'] = $this->language->get('text_success');

		$data['stest'] = true;

		$this->response->setOutput($this->load->view('extension/module/xds_fastorder', $data));
	}
}
