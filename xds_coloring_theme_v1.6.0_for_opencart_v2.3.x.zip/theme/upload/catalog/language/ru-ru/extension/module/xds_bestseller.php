<?php
// Heading
$_['heading_title'] = 'Бестселлеры';

// Text
$_['text_tax']      = 'Без налога:';
$_['text_days']      = ' дн.';
$_['button_wishlist']      = 'В закладки';
$_['button_compare']      = 'В сравнение';