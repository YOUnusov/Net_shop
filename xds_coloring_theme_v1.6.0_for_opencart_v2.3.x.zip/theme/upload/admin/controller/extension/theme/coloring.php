<?php
class ControllerExtensionThemeColoring extends Controller {
	private $error = array();

	public function index() {
		$this->load->language('extension/theme/coloring');

		$this->document->setTitle($this->language->get('heading_title'));
		$this->document->addStyle('view/stylesheet/xds_coloring_theme.css');

		
		$this->load->model('coloring/coloring');
		$this->load->model('design/layout');
		
		$this->load->model('tool/image');
		$data['placeholder'] = $this->model_tool_image->resize('no_image.png', 60, 60);
		
		$this->load->model('localisation/language');

		$languages = $this->model_localisation_language->getLanguages();
		$language_id = $this->config->get('config_language_id');
		$data['languages'] = $this->model_localisation_language->getLanguages();
		$data['language_id'] = $this->config->get('config_language_id');

		if (($this->request->server['REQUEST_METHOD'] == 'POST') && $this->validate()) {
			$this->model_coloring_coloring->changeColoringTheme('coloring', $this->request->post, $this->request->get['store_id']);
			if ($this->lic_validate()) {
				$this->session->data['success'] = $this->language->get('text_success');
				$this->response->redirect($this->url->link('extension/extension', 'token=' . $this->session->data['token'] . '&type=theme', true));
			}		
		}
		
		

		$data['heading_title'] = $this->language->get('heading_title');

		$data['text_edit'] = $this->language->get('text_edit');
		$data['text_enabled'] = $this->language->get('text_enabled');
		$data['text_disabled'] = $this->language->get('text_disabled');
		$data['text_product'] = $this->language->get('text_product');
		$data['text_image'] = $this->language->get('text_image');
		$data['text_general'] = $this->language->get('text_general');
		
		$data['entry_directory'] = $this->language->get('entry_directory');
		$data['entry_status'] = $this->language->get('entry_status');		
		$data['entry_product_limit'] = $this->language->get('entry_product_limit');
		$data['entry_product_description_length'] = $this->language->get('entry_product_description_length');
		$data['entry_image_category'] = $this->language->get('entry_image_category');
		$data['entry_image_thumb'] = $this->language->get('entry_image_thumb');
		$data['entry_image_popup'] = $this->language->get('entry_image_popup');
		$data['entry_image_product'] = $this->language->get('entry_image_product');
		$data['entry_image_additional'] = $this->language->get('entry_image_additional');
		$data['entry_image_related'] = $this->language->get('entry_image_related');
		$data['entry_image_compare'] = $this->language->get('entry_image_compare');
		$data['entry_image_wishlist'] = $this->language->get('entry_image_wishlist');
		$data['entry_image_cart'] = $this->language->get('entry_image_cart');
		$data['entry_image_location'] = $this->language->get('entry_image_location');
		$data['entry_width'] = $this->language->get('entry_width');
		$data['entry_height'] = $this->language->get('entry_height');
		
		$data['help_product_limit'] = $this->language->get('help_product_limit');
		$data['help_product_description_length'] = $this->language->get('help_product_description_length');
		$data['help_directory'] = $this->language->get('help_directory');

		$data['button_save'] = $this->language->get('button_save');
		$data['button_cancel'] = $this->language->get('button_cancel');

		if (isset($this->error['warning'])) {
			$data['error_warning'] = $this->error['warning'];
		} else {
			$data['error_warning'] = '';
		}

		if (isset($this->error['product_limit'])) {
			$data['error_product_limit'] = $this->error['product_limit'];
		} else {
			$data['error_product_limit'] = '';
		}

		if (isset($this->error['product_description_length'])) {
			$data['error_product_description_length'] = $this->error['product_description_length'];
		} else {
			$data['error_product_description_length'] = '';
		}

		if (isset($this->error['image_category'])) {
			$data['error_image_category'] = $this->error['image_category'];
		} else {
			$data['error_image_category'] = '';
		}

		if (isset($this->error['image_thumb'])) {
			$data['error_image_thumb'] = $this->error['image_thumb'];
		} else {
			$data['error_image_thumb'] = '';
		}

		if (isset($this->error['image_popup'])) {
			$data['error_image_popup'] = $this->error['image_popup'];
		} else {
			$data['error_image_popup'] = '';
		}

		if (isset($this->error['image_product'])) {
			$data['error_image_product'] = $this->error['image_product'];
		} else {
			$data['error_image_product'] = '';
		}

		if (isset($this->error['image_additional'])) {
			$data['error_image_additional'] = $this->error['image_additional'];
		} else {
			$data['error_image_additional'] = '';
		}

		if (isset($this->error['image_related'])) {
			$data['error_image_related'] = $this->error['image_related'];
		} else {
			$data['error_image_related'] = '';
		}

		if (isset($this->error['image_compare'])) {
			$data['error_image_compare'] = $this->error['image_compare'];
		} else {
			$data['error_image_compare'] = '';
		}

		if (isset($this->error['image_wishlist'])) {
			$data['error_image_wishlist'] = $this->error['image_wishlist'];
		} else {
			$data['error_image_wishlist'] = '';
		}

		if (isset($this->error['image_cart'])) {
			$data['error_image_cart'] = $this->error['image_cart'];
		} else {
			$data['error_image_cart'] = '';
		}

		if (isset($this->error['image_location'])) {
			$data['error_image_location'] = $this->error['image_location'];
		} else {
			$data['error_image_location'] = '';
		}
		
		$data['breadcrumbs'] = array();

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_home'),
			'href' => $this->url->link('common/dashboard', 'token=' . $this->session->data['token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('text_theme'),
			'href' => $this->url->link('extension/theme', 'token=' . $this->session->data['token'], true)
		);

		$data['breadcrumbs'][] = array(
			'text' => $this->language->get('heading_title'),
			'href' => $this->url->link('extension/theme/coloring', 'token=' . $this->session->data['token'] . '&store_id=' . $this->request->get['store_id'], true)
		);

		$data['action'] = $this->url->link('extension/theme/coloring', 'token=' . $this->session->data['token'] . '&store_id=' . $this->request->get['store_id'], true);

		$data['cancel'] = $this->url->link('extension/extension', 'token=' . $this->session->data['token'] . '&type=theme', true);
		
		if (isset($this->request->get['store_id']) && ($this->request->server['REQUEST_METHOD'] != 'POST')) {
			$setting_info = $this->model_coloring_coloring->getColoringTheme('coloring', $this->request->get['store_id']);
		}
		
		
		$data['coloring_directory'] = 'coloring';
		

		if (isset($this->request->post['coloring_product_limit'])) {
			$data['coloring_product_limit'] = $this->request->post['coloring_product_limit'];
		} elseif (isset($setting_info['coloring_product_limit'])) {
			$data['coloring_product_limit'] = $setting_info['coloring_product_limit'];
		} else {
			$data['coloring_product_limit'] = 12;
		}		
		
		if (isset($this->request->post['coloring_status'])) {
			$data['coloring_status'] = $this->request->post['coloring_status'];
		} elseif (isset($setting_info['coloring_status'])) {
			$data['coloring_status'] = $setting_info['coloring_status'];
		} else {
			$data['coloring_status'] = '';
		}
		
		if (isset($this->request->post['coloring_product_description_length'])) {
			$data['coloring_product_description_length'] = $this->request->post['coloring_product_description_length'];
		} elseif (isset($setting_info['coloring_product_description_length'])) {
			$data['coloring_product_description_length'] = $setting_info['coloring_product_description_length'];
		} else {
			$data['coloring_product_description_length'] = 100;
		}
		
		if (isset($this->request->post['coloring_image_category_width'])) {
			$data['coloring_image_category_width'] = $this->request->post['coloring_image_category_width'];
		} elseif (isset($setting_info['coloring_image_category_width'])) {
			$data['coloring_image_category_width'] = $setting_info['coloring_image_category_width'];
		} else {
			$data['coloring_image_category_width'] = 80;		
		}
		
		if (isset($this->request->post['coloring_image_category_height'])) {
			$data['coloring_image_category_height'] = $this->request->post['coloring_image_category_height'];
		} elseif (isset($setting_info['coloring_image_category_height'])) {
			$data['coloring_image_category_height'] = $setting_info['coloring_image_category_height'];
		} else {
			$data['coloring_image_category_height'] = 80;
		}
		
		if (isset($this->request->post['coloring_image_thumb_width'])) {
			$data['coloring_image_thumb_width'] = $this->request->post['coloring_image_thumb_width'];
		} elseif (isset($setting_info['coloring_image_thumb_width'])) {
			$data['coloring_image_thumb_width'] = $setting_info['coloring_image_thumb_width'];
		} else {
			$data['coloring_image_thumb_width'] = 380;
		}
		
		if (isset($this->request->post['coloring_image_thumb_height'])) {
			$data['coloring_image_thumb_height'] = $this->request->post['coloring_image_thumb_height'];
		} elseif (isset($setting_info['coloring_image_thumb_height'])) {
			$data['coloring_image_thumb_height'] = $setting_info['coloring_image_thumb_height'];
		} else {
			$data['coloring_image_thumb_height'] = 380;		
		}
		
		if (isset($this->request->post['coloring_image_popup_width'])) {
			$data['coloring_image_popup_width'] = $this->request->post['coloring_image_popup_width'];
		} elseif (isset($setting_info['coloring_image_popup_width'])) {
			$data['coloring_image_popup_width'] = $setting_info['coloring_image_popup_width'];
		} else {
			$data['coloring_image_popup_width'] = 800;
		}
		
		if (isset($this->request->post['coloring_image_popup_height'])) {
			$data['coloring_image_popup_height'] = $this->request->post['coloring_image_popup_height'];
		} elseif (isset($setting_info['coloring_image_popup_height'])) {
			$data['coloring_image_popup_height'] = $setting_info['coloring_image_popup_height'];
		} else {
			$data['coloring_image_popup_height'] = 800;
		}
		
		if (isset($this->request->post['coloring_image_product_width'])) {
			$data['coloring_image_product_width'] = $this->request->post['coloring_image_product_width'];
		} elseif (isset($setting_info['coloring_image_product_width'])) {
			$data['coloring_image_product_width'] = $setting_info['coloring_image_product_width'];
		} else {
			$data['coloring_image_product_width'] = 220;
		}
		
		if (isset($this->request->post['coloring_image_product_height'])) {
			$data['coloring_image_product_height'] = $this->request->post['coloring_image_product_height'];
		} elseif (isset($setting_info['coloring_image_product_height'])) {
			$data['coloring_image_product_height'] = $setting_info['coloring_image_product_height'];
		} else {
			$data['coloring_image_product_height'] = 220;
		}
		
		if (isset($this->request->post['coloring_image_additional_width'])) {
			$data['coloring_image_additional_width'] = $this->request->post['coloring_image_additional_width'];
		} elseif (isset($setting_info['coloring_image_additional_width'])) {
			$data['coloring_image_additional_width'] = $setting_info['coloring_image_additional_width'];
		} else {
			$data['coloring_image_additional_width'] = 69;
		}
		
		if (isset($this->request->post['coloring_image_additional_height'])) {
			$data['coloring_image_additional_height'] = $this->request->post['coloring_image_additional_height'];
		} elseif (isset($setting_info['coloring_image_additional_height'])) {
			$data['coloring_image_additional_height'] = $setting_info['coloring_image_additional_height'];
		} else {
			$data['coloring_image_additional_height'] = 69;
		}
		
		if (isset($this->request->post['coloring_image_related_width'])) {
			$data['coloring_image_related_width'] = $this->request->post['coloring_image_related_width'];
		} elseif (isset($setting_info['coloring_image_related_width'])) {
			$data['coloring_image_related_width'] = $setting_info['coloring_image_related_width'];
		} else {
			$data['coloring_image_related_width'] = 180;
		}
		
		if (isset($this->request->post['coloring_image_related_height'])) {
			$data['coloring_image_related_height'] = $this->request->post['coloring_image_related_height'];
		} elseif (isset($setting_info['coloring_image_related_height'])) {
			$data['coloring_image_related_height'] = $setting_info['coloring_image_related_height'];
		} else {
			$data['coloring_image_related_height'] = 180;
		}
		
		if (isset($this->request->post['coloring_image_compare_width'])) {
			$data['coloring_image_compare_width'] = $this->request->post['coloring_image_compare_width'];
		} elseif (isset($setting_info['coloring_image_compare_width'])) {
			$data['coloring_image_compare_width'] = $setting_info['coloring_image_compare_width'];
		} else {
			$data['coloring_image_compare_width'] = 90;
		}
		
		if (isset($this->request->post['coloring_image_compare_height'])) {
			$data['coloring_image_compare_height'] = $this->request->post['coloring_image_compare_height'];
		} elseif (isset($setting_info['coloring_image_compare_height'])) {
			$data['coloring_image_compare_height'] = $setting_info['coloring_image_compare_height'];
		} else {
			$data['coloring_image_compare_height'] = 90;
		}
		
		if (isset($this->request->post['coloring_image_wishlist_width'])) {
			$data['coloring_image_wishlist_width'] = $this->request->post['coloring_image_wishlist_width'];
		} elseif (isset($setting_info['coloring_image_wishlist_width'])) {
			$data['coloring_image_wishlist_width'] = $setting_info['coloring_image_wishlist_width'];
		} else {
			$data['coloring_image_wishlist_width'] = 47;
		}
		
		if (isset($this->request->post['coloring_image_wishlist_height'])) {
			$data['coloring_image_wishlist_height'] = $this->request->post['coloring_image_wishlist_height'];
		} elseif (isset($setting_info['coloring_image_wishlist_height'])) {
			$data['coloring_image_wishlist_height'] = $setting_info['coloring_image_wishlist_height'];
		} else {
			$data['coloring_image_wishlist_height'] = 47;
		}
		
		if (isset($this->request->post['coloring_image_cart_width'])) {
			$data['coloring_image_cart_width'] = $this->request->post['coloring_image_cart_width'];
		} elseif (isset($setting_info['coloring_image_cart_width'])) {
			$data['coloring_image_cart_width'] = $setting_info['coloring_image_cart_width'];
		} else {
			$data['coloring_image_cart_width'] = 47;
		}
		
		if (isset($this->request->post['coloring_image_cart_height'])) {
			$data['coloring_image_cart_height'] = $this->request->post['coloring_image_cart_height'];
		} elseif (isset($setting_info['coloring_image_cart_height'])) {
			$data['coloring_image_cart_height'] = $setting_info['coloring_image_cart_height'];
		} else {
			$data['coloring_image_cart_height'] = 47;
		}
		
		if (isset($this->request->post['coloring_image_location_width'])) {
			$data['coloring_image_location_width'] = $this->request->post['coloring_image_location_width'];
		} elseif (isset($setting_info['coloring_image_location_width'])) {
			$data['coloring_image_location_width'] = $setting_info['coloring_image_location_width'];
		} else {
			$data['coloring_image_location_width'] = 268;
		}
		
		if (isset($this->request->post['coloring_image_location_height'])) {
			$data['coloring_image_location_height'] = $this->request->post['coloring_image_location_height'];
		} elseif (isset($setting_info['coloring_image_location_height'])) {
			$data['coloring_image_location_height'] = $setting_info['coloring_image_location_height'];
		} else {
			$data['coloring_image_location_height'] = 50;
		}
		
		
		// help header menu
		
		if (isset($this->request->post['t1_help_menu_toggle'])) {
			$data['t1_help_menu_toggle'] = $this->request->post['t1_help_menu_toggle'];
		} elseif (isset($setting_info['t1_help_menu_toggle'])) {
			$data['t1_help_menu_toggle'] = $setting_info['t1_help_menu_toggle'];
		} else {
			$data['t1_help_menu_toggle'] = false;
		}
		
		if (isset($this->request->post['t1_help_menu_text'])) {
			$data['t1_help_menu_text'] = $this->request->post['t1_help_menu_text'];
		} elseif (isset($setting_info['t1_help_menu_text'])) {
			$data['t1_help_menu_text'] = $setting_info['t1_help_menu_text'];
		} else {
			$data['t1_help_menu_text'] = false;
		}
		
		if (isset($this->request->post['t1_help_menu_left'])) {
			$data['t1_help_menu_left'] = $this->request->post['t1_help_menu_left'];
		} elseif (isset($setting_info['t1_help_menu_left'])) {
			$data['t1_help_menu_left'] = $setting_info['t1_help_menu_left'];
		} else {
			$data['t1_help_menu_left'] = false;
		}
		
		if (isset($this->request->post['t1_help_menu_item'])) {
			$results = $this->request->post['t1_help_menu_item'];
		} elseif (isset($setting_info['t1_help_menu_item'])) {
			$results = $setting_info['t1_help_menu_item'];
		} else {
			$results = array();
		}

		$data['t1_help_menu_items'] = array();
		
		foreach ($results as $result) {
			$data['t1_help_menu_items'][] = array(
					'title' => $result['title'],
					'link'  => $result['link'],
					'sort'  => $result['sort']
				);	
			} 
		
		
		// main header menu
		
		if (isset($this->request->post['t1_main_menu_toggle'])) {
			$data['t1_main_menu_toggle'] = $this->request->post['t1_main_menu_toggle'];
		} elseif (isset($setting_info['t1_main_menu_toggle'])) {
			$data['t1_main_menu_toggle'] = $setting_info['t1_main_menu_toggle'];
		} else {
			$data['t1_main_menu_toggle'] = false;
		}
		
		if (isset($this->request->post['t1_main_menu_item'])) {
			$results = $this->request->post['t1_main_menu_item'];
		} elseif (isset($setting_info['t1_main_menu_item'])) {
			$results = $setting_info['t1_main_menu_item'];
		} else {
			$results = array();
		}

		$data['t1_main_menu_items'] = array();
		
		foreach ($results as $result) {
			$data['t1_main_menu_items'][] = array(
					'title' => $result['title'],
					'link'  => $result['link'],
					'sort'  => $result['sort']
				);	
			}
			
			
			
			
			
			
			
			
			
			
			
			
			
			
		// add links to category, categoryes settings
		
		if (isset($this->request->post['t1_category_mask_toggle'])) {
			$data['t1_category_mask_toggle'] = $this->request->post['t1_category_mask_toggle'];
		} elseif (isset($setting_info['t1_category_mask_toggle'])) {
			$data['t1_category_mask_toggle'] = $setting_info['t1_category_mask_toggle'];
		} else {
			$data['t1_category_mask_toggle'] = false;
		}
		
		if (isset($this->request->post['t1_category_third_level_toggle'])) {
			$data['t1_category_third_level_toggle'] = $this->request->post['t1_category_third_level_toggle'];
		} elseif (isset($setting_info['t1_category_third_level_toggle'])) {
			$data['t1_category_third_level_toggle'] = $setting_info['t1_category_third_level_toggle'];
		} else {
			$data['t1_category_third_level_toggle'] = false;
		}
		
		if (isset($this->request->post['t1_category_third_level_limit'])) {
			$data['t1_category_third_level_limit'] = $this->request->post['t1_category_third_level_limit'];
		} elseif (isset($setting_info['t1_category_third_level_limit'])) {
			$data['t1_category_third_level_limit'] = $setting_info['t1_category_third_level_limit'];
		} else {
			$data['t1_category_third_level_limit'] = 5;
		}
		
		if (isset($this->request->post['t1_category_no_full_height_submenu'])) {
			$data['t1_category_no_full_height_submenu'] = $this->request->post['t1_category_no_full_height_submenu'];
		} elseif (isset($setting_info['t1_category_no_full_height_submenu'])) {
			$data['t1_category_no_full_height_submenu'] = $setting_info['t1_category_no_full_height_submenu'];
		} else {
			$data['t1_category_no_full_height_submenu'] = false;
		}
		
		if (isset($this->request->post['t1_add_cat_links_toggle'])) {
			$data['t1_add_cat_links_toggle'] = $this->request->post['t1_add_cat_links_toggle'];
		} elseif (isset($setting_info['t1_add_cat_links_toggle'])) {
			$data['t1_add_cat_links_toggle'] = $setting_info['t1_add_cat_links_toggle'];
		} else {
			$data['t1_add_cat_links_toggle'] = false;
		}
		
		if (isset($this->request->post['t1_add_cat_links_item'])) {
			$results = $this->request->post['t1_add_cat_links_item'];
		} elseif (isset($setting_info['t1_add_cat_links_item'])) {
			$results = $setting_info['t1_add_cat_links_item'];
		} else {
			$results = array();
		}

		$data['t1_add_cat_links_items'] = array();
		
		foreach ($results as $result) {
			
			if (is_file(DIR_IMAGE . $result['image_peace'])) {
				$image_peace = $result['image_peace'];
				$thumb_peace = $result['image_peace'];
			} else {
				$image_peace = '';
				$thumb_peace = 'no_image.png';
			}
			
			if (is_file(DIR_IMAGE . $result['image_hover'])) {
				$image_hover = $result['image_hover'];
				$thumb_hover = $result['image_hover'];
			} else {
				$image_hover = '';
				$thumb_hover = 'no_image.png';
			}
			
			$data['t1_add_cat_links_items'][] = array(
					'image_peace' => $image_peace,
					'image_hover' => $image_hover,
					'thumb_peace' => $this->model_tool_image->resize($thumb_peace, 60, 60),
					'thumb_hover' => $this->model_tool_image->resize($thumb_hover, 60, 60),
					'title'			  => $result['title'],
					'link'  			=> $result['link'],
					'position'		=> $result['position'],
					'sort'  			=> $result['sort']
				);	
			}
			
			
			
		$this->load->model('catalog/category');
		
		$data['categories'] = array();

		$filter_data = array(
			'sort'  => 'name',
			'order' => 'ASC'
		);

		$results = $this->model_catalog_category->getCategories($filter_data);

		
		if (isset($this->request->post['t1_category_icon'])) {
			$data['t1_category_icon'] = $this->request->post['t1_category_icon'];
			$category_icon = $this->request->post['t1_category_icon'];
		} elseif (isset($setting_info['t1_category_icon'])) {
			$data['t1_category_icon'] = $setting_info['t1_category_icon'];
			$category_icon = $setting_info['t1_category_icon'];
		}
		
		
		foreach ($results as $result) {
			$data['categories'][] = array(
				'category_id' => $result['category_id'],
				'name'        => $result['name'],
			);
			
			if (isset($category_icon[$result['category_id']]['peace']) && is_file(DIR_IMAGE . $category_icon[$result['category_id']]['peace'])) {
				$data['category_icon_thumb'][$result['category_id']]['peace'] = $this->model_tool_image->resize($category_icon[$result['category_id']]['peace'], 100, 100);
				$data['t1_category_icon'][$result['category_id']]['peace'] = $category_icon[$result['category_id']]['peace'];
			} else {
				$data['category_icon_thumb'][$result['category_id']]['peace'] = $this->model_tool_image->resize('no_image.png', 100, 100);
				$data['t1_category_icon'][$result['category_id']]['peace'] = '';
			}
			
			if (isset($category_icon[$result['category_id']]['hover']) && is_file(DIR_IMAGE . $category_icon[$result['category_id']]['hover'])) {
				$data['category_icon_thumb'][$result['category_id']]['hover'] = $this->model_tool_image->resize($category_icon[$result['category_id']]['hover'], 100, 100);
				$data['t1_category_icon'][$result['category_id']]['hover'] = $category_icon[$result['category_id']]['hover'];
			} else {
				$data['category_icon_thumb'][$result['category_id']]['hover'] = $this->model_tool_image->resize('no_image.png', 100, 100);
				$data['t1_category_icon'][$result['category_id']]['hover'] = '';
			}
		}
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		
		

		// pay icons banner

		if (isset($this->request->post['t1_pay_icons_toggle'])) {
			$data['t1_pay_icons_toggle'] = $this->request->post['t1_pay_icons_toggle'];
		} elseif (isset($setting_info['t1_pay_icons_toggle'])) {
			$data['t1_pay_icons_toggle'] = $setting_info['t1_pay_icons_toggle'];
		} else {
			$data['t1_pay_icons_toggle'] = false;
		}
		
		if (isset($this->request->post['t1_pay_icons_banner_id'])) {
			$data['t1_pay_icons_banner_id'] = $this->request->post['t1_pay_icons_banner_id'];
		} elseif (isset($setting_info['t1_pay_icons_banner_id'])) {
			$data['t1_pay_icons_banner_id'] = $setting_info['t1_pay_icons_banner_id'];
		} else {
			$data['t1_pay_icons_banner_id'] = -1;
		}
			
		$this->load->model('design/banner');
		$data['banners'] = $this->model_design_banner->getBanners();
		
		// footer map code
		
		if (isset($this->request->post['t1_footer_map_toggle'])) {
			$data['t1_footer_map_toggle'] = $this->request->post['t1_footer_map_toggle'];
		} elseif (isset($setting_info['t1_footer_map_toggle'])) {
			$data['t1_footer_map_toggle'] = $setting_info['t1_footer_map_toggle'];
		} else {
			$data['t1_footer_map_toggle'] = false;
		}
		
		if (isset($this->request->post['t1_footer_map'])) {
			$data['t1_footer_map'] = $this->request->post['t1_footer_map'];
		} elseif (isset($setting_info['t1_footer_map'])) {
			$data['t1_footer_map'] = $setting_info['t1_footer_map'];
		} else {
			$data['t1_footer_map'] = false;
		}
		
		// contacts header
		
		if (isset($this->request->post['t1_contact_main_toggle'])) {
			$data['t1_contact_main_toggle'] = $this->request->post['t1_contact_main_toggle'];
		} elseif (isset($setting_info['t1_contact_main_toggle'])) {
			$data['t1_contact_main_toggle'] = $setting_info['t1_contact_main_toggle'];
		} else {
			$data['t1_contact_main_toggle'] = false;
		}
		
		if (isset($this->request->post['t1_callback_form_toggle'])) {
			$data['t1_callback_form_toggle'] = $this->request->post['t1_callback_form_toggle'];
		} elseif (isset($setting_info['t1_callback_form_toggle'])) {
			$data['t1_callback_form_toggle'] = $setting_info['t1_callback_form_toggle'];
		} else {
			$data['t1_callback_form_toggle'] = false;
		}
		
		if (isset($this->request->post['t1_callback_form_button_text'])) {
			$data['t1_callback_form_button_text'] = $this->request->post['t1_callback_form_button_text'];
		} elseif (isset($setting_info['t1_callback_form_button_text'])) {
			$data['t1_callback_form_button_text'] = $setting_info['t1_callback_form_button_text'];
		} else {
			$data['t1_callback_form_button_text'] = false;
		}
		
		if (isset($this->request->post['t1_contact_add_toggle'])) {
			$data['t1_contact_add_toggle'] = $this->request->post['t1_contact_add_toggle'];
		} elseif (isset($setting_info['t1_contact_add_toggle'])) {
			$data['t1_contact_add_toggle'] = $setting_info['t1_contact_add_toggle'];
		} else {
			$data['t1_contact_add_toggle'] = false;
		}
		
		if (isset($this->request->post['t1_contact_main_phone'])) {
			$data['t1_contact_main_phone'] = $this->request->post['t1_contact_main_phone'];
		} elseif (isset($setting_info['t1_contact_main_phone'])) {
			$data['t1_contact_main_phone'] = $setting_info['t1_contact_main_phone'];
		} else {
			$data['t1_contact_main_phone'] = false;
		}
		
		if (isset($this->request->post['t1_contact_hint'])) {
			$data['t1_contact_hint'] = $this->request->post['t1_contact_hint'];
		} elseif (isset($setting_info['t1_contact_hint'])) {
			$data['t1_contact_hint'] = $setting_info['t1_contact_hint'];
		} else {
			$data['t1_contact_hint'] = false;
		}
		
		
		
		if (isset($this->request->post['t1_header_contact'])) {
			$results = $this->request->post['t1_header_contact'];
		} elseif (isset($setting_info['t1_header_contact'])) {
			$results = $setting_info['t1_header_contact'];
		} else {
			$results = array();
		}

		$data['t1_header_contacts'] = array();
		
		foreach ($results as $result) {
		
			if (is_file(DIR_IMAGE . $result['image'])) {
				$image = $result['image'];
				$thumb = $result['image'];
			} else {
				$image = '';
				$thumb = 'no_image.png';
			}
		
			$data['t1_header_contacts'][] = array(
				'image' => $image,
				'thumb' => $this->model_tool_image->resize($thumb, 60, 60),
				'title' => $result['title'],
				'sort'  => $result['sort']
			);	
		} 
		
		
		
		
		if (isset($this->request->post['t1_contact_email'])) {
			$data['t1_contact_email'] = $this->request->post['t1_contact_email'];
		} elseif (isset($setting_info['t1_contact_email'])) {
			$data['t1_contact_email'] = $setting_info['t1_contact_email'];
		} else {
			$data['t1_contact_email'] = false;
		}
		
		if (isset($this->request->post['t1_schedule'])) {
			$data['t1_schedule'] = $this->request->post['t1_schedule'];
		} elseif (isset($setting_info['t1_schedule'])) {
			$data['t1_schedule'] = $setting_info['t1_schedule'];
		} else {
			$data['t1_schedule'] = false;
		}
		
		if (isset($this->request->post['t1_additional_contact'])) {
			$results = $this->request->post['t1_additional_contact'];
		} elseif (isset($setting_info['t1_additional_contact'])) {
			$results = $setting_info['t1_additional_contact'];
		} else {
			$results = array();
		}

		$data['t1_additional_contacts'] = array();
		
		foreach ($results as $result) {
		
			if (is_file(DIR_IMAGE . $result['image'])) {
				$image = $result['image'];
				$thumb = $result['image'];
			} else {
				$image = '';
				$thumb = 'no_image.png';
			}
		
			$data['t1_additional_contacts'][] = array(
				'image' => $image,
				'thumb' => $this->model_tool_image->resize($thumb, 60, 60),
				'link' => $result['link'],
				'title' => $result['title'],
				'sort'  => $result['sort']
			);	
		} 
		
		// instaled modules
		
		if (isset($this->request->post['t1_new_home_layout_module'])) {
			$data['t1_new_home_layout_modules'] = $this->request->post['t1_new_home_layout_module'];
		} elseif (isset($setting_info['t1_new_home_layout_module'])) {
			$data['t1_new_home_layout_modules'] = $setting_info['t1_new_home_layout_module'];
		} else {
			$data['t1_new_home_layout_modules'] = array();
		}

		$this->load->model('extension/extension');

		$this->load->model('extension/module');

		$data['new_home_extensions'] = array();

		// Get a list of installed modules
		$new_home_extensions = $this->model_extension_extension->getInstalled('module');

		// Add all the modules which have multiple settings for each module
		foreach ($new_home_extensions as $code) {
			$this->load->language('module/' . $code);

			$module_data = array();

			$modules = $this->model_extension_module->getModulesByCode($code);

			foreach ($modules as $module) {
				$module_data[] = array(
					'name' => $this->language->get('heading_title') . ' &gt; ' . $module['name'],
					'code' => $code . '.' .  $module['module_id']
				);
			}

			if ($this->config->has($code . '_status') || $module_data) {
				$data['new_home_extensions'][] = array(
					'name'   => strip_tags($this->language->get('heading_title')),
					'code'   => $code,
					'module' => $module_data
				);
			}
		}
		
		if (isset($this->request->post['t1_left_subcategory'])) {
			$data['t1_left_subcategory'] = $this->request->post['t1_left_subcategory'];
		} elseif (isset($setting_info['t1_left_subcategory'])) {
			$data['t1_left_subcategory'] = $setting_info['t1_left_subcategory'];
		} else {
			$data['t1_left_subcategory'] = false;
		}
		
		if (isset($this->request->post['t1_category_description_position'])) {
			$data['t1_category_description_position'] = $this->request->post['t1_category_description_position'];
		} elseif (isset($setting_info['t1_category_description_position'])) {
			$data['t1_category_description_position'] = $setting_info['t1_category_description_position'];
		} else {
			$data['t1_category_description_position'] = false;
		}
		
		if (isset($this->request->post['t1_product_short_description'])) {
			$data['t1_product_short_description'] = $this->request->post['t1_product_short_description'];
		} elseif (isset($setting_info['t1_product_short_description'])) {
			$data['t1_product_short_description'] = $setting_info['t1_product_short_description'];
		} else {
			$data['t1_product_short_description'] = false;
		}
		
		if (isset($this->request->post['t1_product_short_attributes'])) {
			$data['t1_product_short_attributes'] = $this->request->post['t1_product_short_attributes'];
		} elseif (isset($setting_info['t1_product_short_attributes'])) {
			$data['t1_product_short_attributes'] = $setting_info['t1_product_short_attributes'];
		} else {
			$data['t1_product_short_attributes'] = false;
		}
		
		if (isset($this->request->post['t1_product_social_likes'])) {
			$data['t1_product_social_likes'] = $this->request->post['t1_product_social_likes'];
		} elseif (isset($setting_info['t1_product_social_likes'])) {
			$data['t1_product_social_likes'] = $setting_info['t1_product_social_likes'];
		} else {
			$data['t1_product_social_likes'] = false;
		}
		
		if (isset($this->request->post['t1_related_product_position'])) {
			$data['t1_related_product_position'] = $this->request->post['t1_related_product_position'];
		} elseif (isset($setting_info['t1_related_product_position'])) {
			$data['t1_related_product_position'] = $setting_info['t1_related_product_position'];
		} else {
			$data['t1_related_product_position'] = false;
		}
		
		if (isset($this->request->post['t1_disable_cart_button'])) {
			$data['t1_disable_cart_button'] = $this->request->post['t1_disable_cart_button'];
		} elseif (isset($setting_info['t1_disable_cart_button'])) {
			$data['t1_disable_cart_button'] = $setting_info['t1_disable_cart_button'];
		} else {
			$data['t1_disable_cart_button'] = false;
		}
		
		if (isset($this->request->post['t1_disable_cart_button_text'])) {
			$data['t1_disable_cart_button_text'] = $this->request->post['t1_disable_cart_button_text'];
		} elseif (isset($setting_info['t1_disable_cart_button_text'])) {
			$data['t1_disable_cart_button_text'] = $setting_info['t1_disable_cart_button_text'];
		} else {
			$data['t1_disable_cart_button_text'] = false;
		}
		
		if (isset($this->request->post['t1_on_off_qview'])) {
			$data['t1_on_off_qview'] = $this->request->post['t1_on_off_qview'];
		} elseif (isset($setting_info['t1_on_off_qview'])) {
			$data['t1_on_off_qview'] = $setting_info['t1_on_off_qview'];
		} else {
			$data['t1_on_off_qview'] = false;
		}
		
		if (isset($this->request->post['t1_on_off_fastorder'])) {
			$data['t1_on_off_fastorder'] = $this->request->post['t1_on_off_fastorder'];
		} elseif (isset($setting_info['t1_on_off_fastorder'])) {
			$data['t1_on_off_fastorder'] = $setting_info['t1_on_off_fastorder'];
		} else {
			$data['t1_on_off_fastorder'] = false;
		}
		
		if (isset($this->request->post['t1_second_button'])) {
			$data['t1_second_button'] = $this->request->post['t1_second_button'];
		} elseif (isset($setting_info['t1_second_button'])) {
			$data['t1_second_button'] = $setting_info['t1_second_button'];
		} else {
			$data['t1_second_button'] = false;
		}
		
		if (isset($this->request->post['t1_col_left_button_text'])) {
			$data['t1_col_left_button_text'] = $this->request->post['t1_col_left_button_text'];
		} elseif (isset($setting_info['t1_col_left_button_text'])) {
			$data['t1_col_left_button_text'] = $setting_info['t1_col_left_button_text'];
		} else {
			$data['t1_col_left_button_text'] = false;
		}
		
		if (isset($this->request->post['t1_col_right_button_text'])) {
			$data['t1_col_right_button_text'] = $this->request->post['t1_col_right_button_text'];
		} elseif (isset($setting_info['t1_col_right_button_text'])) {
			$data['t1_col_right_button_text'] = $setting_info['t1_col_right_button_text'];
		} else {
			$data['t1_col_right_button_text'] = false;
		}

		
// ------------------------------------------------------------------------------------------

		$data['header'] = $this->load->controller('common/header');
		$data['column_left'] = $this->load->controller('common/column_left');
		$data['footer'] = $this->load->controller('common/footer');

		$this->response->setOutput($this->load->view('extension/theme/coloring', $data));
	}
	
	protected function lic_validate() {
		if (!empty($this->session->data['lic_err'])) {
			$this->error['warning'] = $this->session->data['lic_err'];
		}
		return !$this->error;
	}

	protected function validate() {
		if (!$this->user->hasPermission('modify', 'extension/theme/coloring')) {
			$this->error['warning'] = $this->language->get('error_permission');
		}

		if (!$this->request->post['coloring_product_limit']) {
			$this->error['product_limit'] = $this->language->get('error_limit');
		}

		if (!$this->request->post['coloring_product_description_length']) {
			$this->error['product_description_length'] = $this->language->get('error_limit');
		}

		if (!$this->request->post['coloring_image_category_width'] || !$this->request->post['coloring_image_category_height']) {
			$this->error['image_category'] = $this->language->get('error_image_category');
		}

		if (!$this->request->post['coloring_image_thumb_width'] || !$this->request->post['coloring_image_thumb_height']) {
			$this->error['image_thumb'] = $this->language->get('error_image_thumb');
		}

		if (!$this->request->post['coloring_image_popup_width'] || !$this->request->post['coloring_image_popup_height']) {
			$this->error['image_popup'] = $this->language->get('error_image_popup');
		}

		if (!$this->request->post['coloring_image_product_width'] || !$this->request->post['coloring_image_product_height']) {
			$this->error['image_product'] = $this->language->get('error_image_product');
		}

		if (!$this->request->post['coloring_image_additional_width'] || !$this->request->post['coloring_image_additional_height']) {
			$this->error['image_additional'] = $this->language->get('error_image_additional');
		}

		if (!$this->request->post['coloring_image_related_width'] || !$this->request->post['coloring_image_related_height']) {
			$this->error['image_related'] = $this->language->get('error_image_related');
		}

		if (!$this->request->post['coloring_image_compare_width'] || !$this->request->post['coloring_image_compare_height']) {
			$this->error['image_compare'] = $this->language->get('error_image_compare');
		}

		if (!$this->request->post['coloring_image_wishlist_width'] || !$this->request->post['coloring_image_wishlist_height']) {
			$this->error['image_wishlist'] = $this->language->get('error_image_wishlist');
		}

		if (!$this->request->post['coloring_image_cart_width'] || !$this->request->post['coloring_image_cart_height']) {
			$this->error['image_cart'] = $this->language->get('error_image_cart');
		}

		if (!$this->request->post['coloring_image_location_width'] || !$this->request->post['coloring_image_location_height']) {
			$this->error['image_location'] = $this->language->get('error_image_location');
		}

		return !$this->error;
	}
}
