<?php
$_['succes_create_file'] = '<div class="alert alert-success success">Sitemap successfully created</div>';
$_['error_permission'] = 'You have no right to control this module';
?>