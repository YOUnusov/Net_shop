<?php
$_['text_widget_html']          = 'HTML вставка';
$_['text_blog']     = 'по категориям';
