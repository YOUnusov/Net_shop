<?php
// Heading
$_['heading_title']    = '<strong>XDS</strong> &rarr; Coloring Theme. Настройки шаблона';

// Text
$_['text_module']      = 'Модули';
$_['text_success']     = 'Настройки модуля "XDS Coloring &rarr; Настройки шаблона" были успешно изменены';
$_['text_edit']        = 'Изменить модуль "XDS Coloring &rarr; Настройки шаблона"';

// Error
$_['error_permission'] = 'Внимание: у Вас не достаточно прав для изменения этого модуля!';