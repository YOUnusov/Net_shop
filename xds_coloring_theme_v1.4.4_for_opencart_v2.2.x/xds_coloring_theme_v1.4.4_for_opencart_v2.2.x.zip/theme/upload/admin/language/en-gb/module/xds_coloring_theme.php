<?php
// Heading
$_['heading_title']    = '<span style="color:#ff0000;">XDS Coloring &rarr; </span>Theme Control';

// Text
$_['text_module']      = 'Modules';
$_['text_success']     = 'Success: You have modified "XDS Coloring &rarr; Theme Control" module!';
$_['text_edit']        = 'Edit "XDS Coloring &rarr; Theme Control"';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify "XDS Coloring &rarr; Theme Control" module!';