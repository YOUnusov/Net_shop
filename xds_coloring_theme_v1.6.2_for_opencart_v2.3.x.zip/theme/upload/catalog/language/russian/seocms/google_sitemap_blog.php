<?php
$_['succes_create_file'] = '<div class="alert alert-success success">Файл sitemap успешно создан</div>';
$_['error_permission'] = 'У Вас нет прав для управления этим модулем';
?>