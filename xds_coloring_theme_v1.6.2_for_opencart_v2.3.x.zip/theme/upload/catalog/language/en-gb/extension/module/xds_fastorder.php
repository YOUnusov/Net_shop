<?php
// Heading
$_['heading_title']  = 'Fast order';

// Text
$_['text_name']  		 = 'Name: ';
$_['text_phone']     = 'Phone: ';
$_['text_enquiry']   = 'Comment: ';
$_['text_product_name']   = 'Product name: ';
$_['text_product_href']   = 'Product link: ';
$_['text_success']   = 'Your enquiry has been successfully sent to the store owner!';
$_['button_submit']  = 'Order';

// Entry
$_['entry_name']     = 'Your Name';
$_['entry_phone']    = 'Your Phone';
$_['entry_enquiry']  = 'Comment';

// Email
$_['email_subject']  = 'Fast order from %s';

// Errors
$_['error_name']     = 'Name must be between 3 and 32 characters!';
$_['error_phone']    = 'Phone must be between 3 and 20 characters!';
