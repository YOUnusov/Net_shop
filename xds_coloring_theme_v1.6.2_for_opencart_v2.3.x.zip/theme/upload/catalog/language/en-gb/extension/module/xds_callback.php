<?php
// Heading
$_['heading_title']  = 'Call Back';

// Text
$_['text_name']  		 = 'Name: ';
$_['text_phone']     = 'Phone: ';
$_['text_enquiry']   = 'Comment: ';
$_['text_success']   = 'Your enquiry has been successfully sent to the store owner!';
$_['button_submit']  = 'Call me back';

// Entry
$_['entry_name']     = 'Your Name';
$_['entry_phone']    = 'Your Phone';
$_['entry_enquiry']  = 'Comment';

// Email
$_['email_subject']  = 'Call back to %s';

// Errors
$_['error_name']     = 'Name must be between 3 and 32 characters!';
$_['error_phone']    = 'E-Mail Address does not appear to be valid!';
$_['error_enquiry']  = 'Enquiry must be between 10 and 3000 characters!';
