<?php
// Heading
$_['heading_title'] = 'Featured';

// Text
$_['text_tax']      = 'Ex Tax:';
$_['text_days']      = ' d.';
$_['button_wishlist']      = 'Add to Wishlist';
$_['button_compare']      = 'Add to Compare';