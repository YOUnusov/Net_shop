<?php

	foreach ($this->data['languages'] as $language) {
		$further[$language['language_id']] = '<a href="{URL}" class="seocms_further {CLASS}" title="{TITLE}" {DATA}>→</a>';
	}
		$ascp_settings_settings = Array(
	'box_begin' => '<div class="panel panel-default">',
	'box_end' => '</div>',
	'further' => $further
	);
