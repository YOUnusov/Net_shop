<?php
$_['agoo_menu_modules'] = 'Modules';
$_['agoo_menu_options'] = 'Home module';
$_['agoo_menu_layouts'] = 'Layouts';
$_['agoo_menu_widgets'] = 'Widgets';
$_['agoo_menu_categories'] = 'Categories';
$_['agoo_menu_records'] = 'Records';
$_['agoo_menu_comments'] = 'Comments';
$_['agoo_menu_reviews'] = 'Reviews';
$_['agoo_menu_adapter'] = 'Adapter modules tepmlates for theme';
$_['agoo_menu_fields'] = 'Custom fields forms';
$_['agoo_menu_sitemap'] = 'Sitemap';


?>