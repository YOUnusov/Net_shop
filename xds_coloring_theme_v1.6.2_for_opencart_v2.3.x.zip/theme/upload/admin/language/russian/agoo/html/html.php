<?php
$_['text_widget_html']          = 'HTML вставка';
$_['text_separator']          = ' > ';
$_['entry_search']          = 'Форма поиска';

$_['entry_anchor_templates'] = 'Шаблоны привязки';
$_['entry_anchor_value'] = 'Текущее значение';
$_['entry_anchor_templates_clear'] = 'Очистить';

$_['entry_anchor_templates_tab'] = 'Во вкладке (по умолчанию)';
$_['entry_box_begin_templates'] = 'Блок (начальный HTML код) шаблоны';
$_['entry_box_end_templates'] = 'Блок (закрывающий HTML-код) шаблоны';
$_['entry_box_begin_templates_tab'] = 'Блок (начальный HTML код) шаблон в вкладке (по умолчанию)';
$_['entry_box_end_templates_tab'] = 'Блок (закрывающий HTML-код) шаблон в вкладке (по умолчанию)';
$_['entry_box_begin_templates_empty'] = 'Блок (начальный HTML код) шаблон пустой блок (по умолчанию)';
$_['entry_box_end_templates_empty'] = 'Блок (закрывающий HTML-код) шаблон пустой блок (по умолчанию)';
$_['entry_box_begin_value'] = 'Текущее значение';
$_['entry_box_end_value'] = 'Текущее значение';

$_['entry_anchor_templates_html'] = 'html шаблон';
$_['entry_anchor_templates_prepend'] = 'prepend шаблон';
$_['entry_anchor_templates_append'] = 'append шаблон';
$_['entry_anchor_templates_before'] = 'before шаблон';
$_['entry_anchor_templates_after'] = 'after шаблон';
$_['text_anchor_templates_selector'] = 'ВВЕДИТЕ СЕЛЕКТОР TAG, #ID, .CLASS';


?>